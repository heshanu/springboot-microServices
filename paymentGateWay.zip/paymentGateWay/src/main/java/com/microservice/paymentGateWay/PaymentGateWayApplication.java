package com.microservice.paymentGateWay;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PaymentGateWayApplication {

	public static void main(String[] args) {
		SpringApplication.run(PaymentGateWayApplication.class, args);
	}

}
