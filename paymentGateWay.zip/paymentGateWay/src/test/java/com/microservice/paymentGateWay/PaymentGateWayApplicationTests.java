package com.microservice.paymentGateWay;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PaymentGateWayApplicationTests {

	@Test
	void contextLoads() {
	}

}
